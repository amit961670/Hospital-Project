Thanks for downloading this template!

Template Name:
Template URL: https://bootstrapmade.com/free-one-page-bootstrap-template-amoeba/
Author: Amit Kumar
License: https://bootstrapmade.com/license/
